// ========== SIGNUP FUNCTION ==========
function handleSignup(event) {
  event.preventDefault();

  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();
  const confirmPassword = document.getElementById('confirmPassword').value.trim();

  if (!name || !email || !password || !confirmPassword) {
    alert('Please fill in all fields.');
    return;
  }

  if (password !== confirmPassword) {
    alert('Passwords do not match.');
    return;
  }

  const users = JSON.parse(localStorage.getItem('users')) || [];

  const existingUser = users.find(user => user.email === email);
  if (existingUser) {
    alert('Email is already registered. Please log in.');
    return;
  }

  users.push({ name, email, password });
  localStorage.setItem('users', JSON.stringify(users));

  alert('Signup successful! You can now log in.');
  window.location.href = 'login.html';
}

// ========== LOGIN FUNCTION ==========
function handleLogin(event) {
  event.preventDefault();

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();

  if (!email || !password) {
    alert('Please enter both email and password.');
    return;
  }

  const users = JSON.parse(localStorage.getItem('users')) || [];
  const matchedUser = users.find(user => user.email === email && user.password === password);

  if (matchedUser) {
    localStorage.setItem('currentUser', JSON.stringify(matchedUser)); // 🔥 Save logged-in user
    alert('Login successful!');
    window.location.href = '../pages/onboarding1.html';
  } else if (email === 'admin@motorguard.com' && password === '1234') {
    localStorage.setItem('currentUser', JSON.stringify({ name: 'Admin', email })); // Admin case
    alert('Admin login successful!');
    window.location.href = '../pages/onboarding1.html';
  } else {
    alert('Invalid credentials. Please try again.');
  }
}

// ========== FORGOT PASSWORD ==========
function handleForgotPassword(event) {
  event.preventDefault();

  const email = document.getElementById('forgotEmail').value.trim();

  if (!email) {
    alert('Please enter your email.');
    return;
  }

  if (!validateEmail(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  const users = JSON.parse(localStorage.getItem('users')) || [];
  const existingUser = users.find(user => user.email === email);

  if (!existingUser) {
    alert("This email is not registered.");
  } else {
    alert(`Password reset instructions sent to ${email}`);
  }

  document.getElementById("forgotEmail").value = "";
}

// ========== EMAIL VALIDATION ==========
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(String(email).toLowerCase());
}
