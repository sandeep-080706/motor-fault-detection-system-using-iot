function getDeviceIP() {
  // Hardcoded IP for now
  return "http://192.168.27.203/";
}

function saveIP() {
  let ip = document.getElementById("ipInput").value.trim();
  if (!ip.startsWith("http://") && !ip.startsWith("https://")) {
    ip = "http://" + ip;
  }
  try {
    new URL(ip);
    localStorage.setItem("deviceIP", ip);
    alert("✅ IP Address saved!");
  } catch (e) {
    alert("❌ Invalid IP. Please enter a valid one starting with http://");
  }
}

async function updateDashboard() {
  const url = `${getDeviceIP()}vibration`;
  try {
    const response = await fetch(url);
    const data = await response.json();

    const vibration = parseFloat(data.vibration);
    const status = data.status;
    const time = new Date().toLocaleTimeString();

    document.getElementById("faultStatus").textContent = status;
    document.getElementById("vibrationValue").textContent = vibration.toFixed(2);
    document.getElementById("lastUpdated").textContent = time;

    document.getElementById("motorStatus").textContent = status === "FAULT" ? "⚠️ Fault Detected" : "✅ Running Smoothly";
    document.getElementById("sensorStatus").textContent = "Active";

    if (status === "FAULT") {
      localStorage.setItem("lastFaultTime", time);
      let total = parseInt(localStorage.getItem("totalFaults") || 0);
      total += 1;
      localStorage.setItem("totalFaults", total);
    }

    const lastFault = localStorage.getItem("lastFaultTime") || "--";
    const totalFaults = localStorage.getItem("totalFaults") || "--";
    document.getElementById("lastFault").textContent = lastFault;
    document.getElementById("totalFaults").textContent = totalFaults;

  } catch (error) {
    console.error("Dashboard fetch error:", error);
    document.getElementById("faultStatus").textContent = "Error";
    document.getElementById("vibrationValue").textContent = "--";
  }
}

setInterval(updateDashboard, 5000);
updateDashboard();
