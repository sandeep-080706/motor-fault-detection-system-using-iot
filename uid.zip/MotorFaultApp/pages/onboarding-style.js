function nextPage(page) {
    window.location.href = page;
  }
  